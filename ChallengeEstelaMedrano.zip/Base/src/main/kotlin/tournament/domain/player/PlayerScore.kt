package tournament.domain.player

data class PlayerScore(
    val player: Player,
    val score: Int
)