package tournament.domain.player

enum class PlayerPosition {
    G, F, C
}