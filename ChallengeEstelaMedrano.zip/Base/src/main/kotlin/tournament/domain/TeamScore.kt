package tournament.domain

data class TeamScore(
    val team: String,
    val score: Int
)