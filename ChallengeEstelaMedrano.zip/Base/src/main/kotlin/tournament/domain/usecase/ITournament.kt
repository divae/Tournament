package tournament.domain.usecase

interface ITournament {
    fun MVP(): String
}
