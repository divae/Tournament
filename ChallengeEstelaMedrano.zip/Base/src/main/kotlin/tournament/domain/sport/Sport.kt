package tournament.domain.sport

enum class Sport {
    BASKETBALL, HANDBALL
}