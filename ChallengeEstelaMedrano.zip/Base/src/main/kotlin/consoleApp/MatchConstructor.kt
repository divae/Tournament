package consoleApp

import tournament.domain.*
import tournament.domain.sport.Sport
import tournament.domain.player.Player
import tournament.domain.player.PlayerPosition
import tournament.domain.sport.SportStats
import tournament.port.IMatchConstructor
import java.security.InvalidParameterException


class MatchConstructor : IMatchConstructor {
    override fun generate(matchFileText: List<String>): Match {
        try {
            val exportType = Sport.valueOf(matchFileText[0].uppercase())
            val stats = matchFileText.drop(1)
            val playerStats: MutableList<SportStats> = mutableListOf()

            for (line in stats) {
                val game = line.split(";").toTypedArray()
                playerStats.add(
                    SportStats(
                        Player(
                            name = game[0],
                            nickname = game[1],
                            number = game[2].toInt(),
                            teamName = game[3],
                            playerPosition = PlayerPosition.valueOf(game[4])
                        ),
                        rating = when (exportType) {
                            Sport.BASKETBALL -> BasketballRatingPoint(
                                scoredPoint = game[5].toInt(),
                                rebounds = game[6].toInt(),
                                assists = game[7].toInt()
                            )

                            Sport.HANDBALL -> HandballRatingPoint(
                                goalMade = game[5].toInt(),
                                goalReceived = game[6].toInt()
                            )
                        }
                    )
                )
            }
            return Match(
                name = exportType, playerStats = playerStats
            )
        } catch (e: Exception) {
            throw InvalidParameterException("Error when reading the file")
        }
    }

}


