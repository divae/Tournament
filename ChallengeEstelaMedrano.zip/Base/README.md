# Estela Medrano | Overiew
- Architecture: Hexagonal
- Language: Kotlin
- Testing Library: JUnit5
- Automation system: Gradle

Rules:
- The nickname is unique.
- The program does not work if there is a corrupted file.
- Types of sports can increase.

## How to...

### The program works
The program uses the reading of files from a known directory to read them and calculate which player has had the most points in the whole tournament.
The program will select all files with the `.txt` extension (example `file.txt`)

you can find them at source
````
main\resources
````
### execute the program?
````
# exect
kotlin/consoleApp/Program.kt
````

### execute the test?
````
$ .\gradlew test 
````
### Add new sport
1.- Adding the capitalized name to the sports list
```
# Sport.kt
enum class Sport {
    BASKETBALL, HANDBALL, NEWSPORT*
}
```
2.- Modeling the new sport with its scoreboard and properties
```
# RatingPoint.kt
... 
data class NewsportRatingPoint(
    val scoredPoint: Int,
    val rebounds: Int,
    val assists: Int,
) : IRatingPoint {
    private val scoreboard: Map<PlayerPosition, List<Int>> = mapOf(PlayerPosition.G to listOf(2, 3, 1), PlayerPosition.F to listOf(2, 2, 2), PlayerPosition.C to listOf(2, 1, 3))
    override fun score(playerPosition: PlayerPosition, teamWinner: Boolean): Int {
        val recount =
            scoredPoint * scoreboard[playerPosition]!![0] + rebounds * scoreboard[playerPosition]!![1] + assists * scoreboard[playerPosition]!![2]
        return if (teamWinner) recount + 10 else recount
    }
}
....
```
3.- Add the new object in the file translation
```
MatchConstructor.kt
....
 Sport.BASKETBALL -> BasketballRatingPoint(
    scoredPoint = game[5].toInt(),
    rebounds = game[6].toInt(),
    assists = game[7].toInt()
)
Sport.NEWSPORT -> NewsportRatingPoint(
    goalMade = game[5].toInt(),
    goalReceived = game[6].toInt()
)
...
```

## TODO
- Validate that the names are unique.
- Testing corner cases.